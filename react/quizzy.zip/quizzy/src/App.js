import React, { useEffect, useState } from 'react';
import io from 'socket.io-client';
import 'bootstrap/dist/css/bootstrap.min.css';
import Carousel from 'react-bootstrap/Carousel';

const socket = io("http://172.16.8.216:4000");

const QuizApp = () => {
  const [questions, setQuestions] = useState([]);
  const [teams, setTeams] = useState([]);

  useEffect(() => {
    // Listen for WebSocket updates
    socket.on('updateQuestions', (data) => setQuestions(data));
    socket.on('updateScores', (data) => setTeams(data));

    // Fetch initial data from backend
    fetch('http://172.16.8.216:4000/questions')
      .then((res) => res.json())
      .then((data) => setQuestions(data));
    fetch('http://172.16.8.216:4000/teams')
      .then((res) => res.json())
      .then((data) => setTeams(data));

    return () => {
      socket.off('updateQuestions');
      socket.off('updateScores');
    };
  }, []);

  return (
    <div className="container mt-4">
      <h1 className="text-center mb-4">Quiz Dashboard</h1>

      <div className="row mb-5">
        {teams.map((team) => (
          <div key={team._id} className="col-md-4">
            <div className="card text-white bg-primary mb-3">
              <div className="card-body text-center">
                <h5 className="card-title">{team.name.toUpperCase()}</h5>
                <p className="card-text display-4">{team.score}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <h2 className="text-center mb-4">Questions</h2>
      <Carousel>
        {questions.map((q) => (
          <Carousel.Item key={q._id}>
            <div
              className="d-flex flex-column align-items-center justify-content-center"
              style={{ height: '300px' }}
            >
              <h3>{q.text}</h3>
              <ul className="list-group mt-3">
                {q.options.map((opt, index) => (
                  <li key={index} className="list-group-item">{opt}</li>
                ))}
              </ul>
            </div>
          </Carousel.Item>
        ))}
      </Carousel>
    </div>
  );
};

export default QuizApp;
